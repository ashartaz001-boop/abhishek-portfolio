# Abhishek Kumar Dongrey — Portfolio Website (floating 3D card build)

A complete, ready-to-deploy static website. **No build step, nothing to install.**
Open `index.html` and everything is there: content, styling, interactions, images and the 3D hero.

---

## The 3D hero card

The hero has a real, WebGL 3D card floating in space:

* **Front — the real photograph, imprinted full-bleed.** Your photo *is* the card face: it runs
  edge to edge across the rounded card with nothing laid over it.
* **Back — the ID badge panel.** A full identity-card back: monogram header, name and function,
  `OPEN TO WORK` status pill, badge portrait, ID number, role, department, location, core-stack
  chips, an 8+ / 35% / 15+ stat panel, signature block, issue and validity dates, a QR-style
  code block, a barcode and the return small print.
* **Real 3D geometry**, not a flat image trick: the card body is an extruded rounded rectangle
  with bevelled edges and a physical material, so you can see the thickness and the light catch
  on the edges as it turns.
* **Drag to rotate** — click/touch and drag anywhere on the card to orbit around it.
* **Flip button** — "Flip to ID badge" turns the card over to the badge panel and back.
* **Idle motion** — gentle bob, drift and slow auto-rotation, plus a soft floor shadow that
  breathes with the float. All motion is disabled automatically for
  `prefers-reduced-motion: reduce`.
* **Graceful fallback** — if WebGL is unavailable, or the page is opened without a server, the
  hero falls back to a clean photo card instead of breaking.

All badge artwork is generated at runtime on `<canvas>` — no external images, no network calls.

### Why the card could look blank (fixed in this build)

The two printed faces are flat planes that must sit **just outside** the bevelled body. The body
is extruded to `CARD_D` and bevelled by `BEVEL` on each side, so its half-depth is
`CARD_D / 2 + BEVEL` = 0.048. The faces are placed at `faceZ = CARD_D / 2 + BEVEL + 0.004` — if
you ever push them back inside that value (or increase `CARD_D`/`BEVEL` without moving `faceZ`),
the body's caps cover them and the tile renders as a blank cream slab that still drags. Keep
`faceZ` greater than `CARD_D / 2 + BEVEL`.

---

## What's in this folder

```
abhishek-portfolio/
├── index.html                  ← the entire website
├── README.md                   ← this file
└── assets/
    ├── profile.jpg             ← your photograph (card front, badge portrait)
    ├── me-3d.jpg               ← 3D model render (About portrait, hero avatar)
    ├── avatar.jpg              ← small square crop of the photo
    ├── three.module.js         ← three.js r170 (local, vendored)
    ├── OrbitControls.js        ← drag-to-rotate controls (local)
    └── RoomEnvironment.js      ← studio light environment (local)
```

Every asset is local and referenced with a relative path, so the folder is fully self-contained
and can be dropped on any static host.

---

## How to publish it (Netlify)

1. Go to <https://app.netlify.com/drop>
2. Drag the whole **`abhishek-portfolio`** folder onto the page
3. Netlify gives you a live URL in a few seconds

The 3D hero needs to be served by a web server (it uses ES modules) — Netlify, Vercel, GitHub
Pages, Cloudflare Pages or any static host all work.

## Previewing locally

Opening the file directly with `file://` will not start the 3D scene (you will just see the photo
fallback), because the card is loaded as an ES module. To preview locally, run a tiny server:

```bash
cd abhishek-portfolio
python3 -m http.server 8080
# then open http://localhost:8080
```

---

## Editing later

* **Text** — headings, bullets and chips are plain HTML inside `index.html`.
* **Colours** — the `:root` variables at the top of the `<style>` block (`--violet`, `--coral`,
  `--sky`, `--mint`, `--ink`).
* **Card front** — `drawFront(photo)` near the bottom of `index.html` paints the photo across the
  card face. It clips the photo to the card's rounded corner and nothing else; if you want a name
  strip, caption or border printed on the front, that is the function to add it in.
* **Card back** — `drawBack(photo)` draws the ID badge panel. Change the badge fields, the ID
  number, the signature or the small print there; the card re-renders on load.
* **Card thickness and face position** — `CARD_D`, `BEVEL` and `faceZ` (see the note above) live
  together in the module script that builds the card. Keep `faceZ > CARD_D / 2 + BEVEL`.
* **Swapping the photo** — replace `assets/profile.jpg` with a new portrait (it is drawn
  cover-fitted, so any size works; a portrait crop around 4:5 looks best) and keep the same file
  name. The card tries `profile.jpg`, then `me-3d.jpg`, then `avatar.jpg`, so the face is never
  left blank.
* **Swapping the 3D model render** — replace `assets/me-3d.jpg` and keep the same file name.

## Notes

* Fonts load from Google Fonts (Fraunces + Manrope) and fall back to Georgia / system sans
  offline — nothing breaks.
* Scroll reveals are progressive: with JavaScript disabled the page still renders fully.
* The 3D scene pauses itself when it scrolls out of view or the tab is hidden.
* Responsive across phone, tablet and desktop.
